﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarDealer.DTOs
{
    public class CustomerDTO
    {
        [JsonProperty("name")]
        public string Name { get; set; } = null!;

        [JsonProperty("birthDate")]
        public DateTime BirthDate { get; set; }


        [JsonProperty("isYoungDriver")]
        public bool IsYoungDriver { get; set; }
    }
}
