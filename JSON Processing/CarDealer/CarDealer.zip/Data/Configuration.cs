﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-MB8TJ24\SQLEXPRESS;Database=CarDealer;Integrated Security=True;Encrypt=False";
    }
}
