﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-MB8TJ24\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
